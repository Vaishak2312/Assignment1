﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Core.Model
{
    public class PersonContext :DbContext
    {
        public PersonContext(DbContextOptions<PersonContext> options) : base(options)
        { } 

        public DbSet<person> persons { get; set; }

    }

        public class person
        {
            [Key]
            public int id { get; set; }
            public string name { get; set; }
            public int age { get; set; }

        }
}
