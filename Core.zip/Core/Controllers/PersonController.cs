﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        PersonContext context = null;
        public PersonController(PersonContext _obj)
        {
            context = _obj; 
              
        }
        [HttpGet]
        public List<person> getPersons()
        {
           
            var listPersons = context.persons.ToList();
            return listPersons;
        }

        [HttpPost]
        public ActionResult InsertPersons(person p)
        {
            
            context.persons.Add(p);
            context.SaveChanges();

            return NoContent();
        }

        [HttpPut]
        public ActionResult UpdatePersons(person p)
        {

            var per = context.persons.Where(i => i.id == p.id).First();
            per.name = p.name;
            per.age = p.age;
            context.SaveChanges();
            

            return NoContent();
        }

        [HttpDelete("(id)")]
        public ActionResult DeletePersons(int id)
        {

            var per = context.persons.Where(i => i.id == id).First();
            context.Remove(per);
           
            context.SaveChanges();
            

            return NoContent();
        }

        //[HttpGet("(id)")]
        //public ActionResult getPersons(int id)
        //{

        //    var per = context.persons.Where(i => i.id == id).First();
            
        //    context.SaveChanges();
            

        //    return per;
        //}




    }
}
